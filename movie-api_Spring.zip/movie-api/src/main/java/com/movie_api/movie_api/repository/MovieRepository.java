package com.movie_api.movie_api.repository;

import org.springframework.boot.autoconfigure.data.jpa.JpaRepositoriesAutoConfiguration;

public class MovieRepository extends JpaRepositoriesAutoConfiguration {
}
