package com.task_tracker_backend.task_tracker_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskTrackerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
