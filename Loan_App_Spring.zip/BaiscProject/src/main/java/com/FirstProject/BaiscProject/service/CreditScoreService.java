package com.FirstProject.BaiscProject.service;

import com.FirstProject.BaiscProject.entity.CreditScore;
import com.FirstProject.BaiscProject.entity.User;
import com.FirstProject.BaiscProject.model.LoanEligibility;
import com.FirstProject.BaiscProject.repository.CreditScoreRepository;
import com.FirstProject.BaiscProject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CreditScoreService {

    @Autowired
    private CreditScoreRepository scoreRepo;

    @Autowired
    private UserRepository userRepo;

    public LoanEligibility checkEligibility(Long userId) {
        User user = userRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        CreditScore score = scoreRepo.findById(userId)
                .orElseThrow(() -> new RuntimeException("Credit score not found"));

        LoanEligibility result = new LoanEligibility();
        result.setUserName(user.getName());
        result.setScore(score.getScore());

        List<String> loans = new ArrayList<>();
        if(score.getScore() >= 750) {
            result.setEligibilityStatus("Eligible for All Loans");
            loans.add("Home Loan");
            loans.add("Personal Loan");
            loans.add("Car Loan");
        } else if(score.getScore() >= 650) {
            result.setEligibilityStatus("Eligible for Personal & Car Loan");
            loans.add("Personal Loan");
            loans.add("Car Loan");
        } else {
            result.setEligibilityStatus("Not Eligible");
        }

        result.setEligibleLoans(loans);
        result.setMessage("Based on your credit score of " + score.getScore());
        return result;
    }
}
