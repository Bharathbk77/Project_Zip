package com.quizapp.quizapp.controller;

import com.quizapp.quizapp.entity.Option;
import com.quizapp.quizapp.entity.Question;
import com.quizapp.quizapp.service.OptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/options")
public class OptionController {
    @Autowired
    private OptionService optionService;

    @PostMapping("/addAll/{questionId}")
    public List<Option> addOptions(@RequestBody List<Option> options,
                                   @PathVariable Long questionId) {
        return optionService.addOptionsToQuestion(options, questionId);
    }



    @GetMapping("/question/{questionId}")
    public List<Option> getAllOptions(@PathVariable Long questionId){
        return optionService.getOptionsByQuestion(questionId);
    }
    @GetMapping("/hello")
    public String hello(){
        return  "Hello Bharath";
    }
}
