//package com.quizapp.quizapp.repository;
//
//import com.quizapp.quizapp.entity.User;
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import java.util.Optional;
//
//
//public interface UserRepository extends JpaRepository<User,Long> {
//    User findByName(String name); // Use Optional
//    Optional<User> findByEmail(String email); // Add findByEmail
//}
//
//

package com.quizapp.quizapp.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.quizapp.quizapp.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByName(String name);
    Optional<User> findByEmail(String email);
}
