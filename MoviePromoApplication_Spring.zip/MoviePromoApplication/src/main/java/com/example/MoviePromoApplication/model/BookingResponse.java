package com.example.MoviePromoApplication.model;
import com.example.MoviePromoApplication.model.EffectResult;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.List;

@Data
@AllArgsConstructor
public class BookingResponse{
    private double originalTotal;
    private double finalTotal;
    private List<EffectResult> appliedEffects;
}