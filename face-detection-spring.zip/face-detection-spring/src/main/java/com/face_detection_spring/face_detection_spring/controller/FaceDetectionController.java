package com.face_detection_spring.face_detection_spring.controller;

import com.face_detection_spring.face_detection_spring.service.FaceDetectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/faces")
public class FaceDetectionController {

    @Autowired
    private FaceDetectionService faceDetectionService;

    @PostMapping("/upload")
    public ResponseEntity<byte[]> uploadAndDetect(@RequestParam("file") MultipartFile file) throws IOException {

        // Sanitize original filename
        String originalFilename = file.getOriginalFilename();
        String sanitizedFilename = originalFilename != null ? new File(originalFilename).getName() : "input.jpg";

        // Extract base name and extension safely
        String baseName = sanitizedFilename.contains(".")
                ? sanitizedFilename.substring(0, sanitizedFilename.lastIndexOf("."))
                : "input";
        String extension = sanitizedFilename.contains(".")
                ? sanitizedFilename.substring(sanitizedFilename.lastIndexOf("."))
                : ".jpg";

        // Generate timestamp
        String timestamp = String.valueOf(System.currentTimeMillis());

        // Define input/output paths
        String inputDir = "C:/Users/bharath.bobbali/Desktop/uploads/";
        String outputDir = "C:/Users/bharath.bobbali/Desktop/outputs/";

        // Ensure directories exist
        Files.createDirectories(Paths.get(inputDir));
        Files.createDirectories(Paths.get(outputDir));

        String inputPath = inputDir + baseName + "_" + timestamp + extension;
        String outputPath = outputDir + baseName + "_output_" + timestamp + ".jpg";

        // Save uploaded file securely
        file.transferTo(new File(inputPath));

        // Process image
        faceDetectionService.detectFaces(inputPath, outputPath);

        // Read processed image
        byte[] outputImage = Files.readAllBytes(Paths.get(outputPath));
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.IMAGE_JPEG);

        return new ResponseEntity<>(outputImage, headers, HttpStatus.OK);
    }
}
