package com.example.makemytrip.MMT.dto;

import lombok.Data;

@Data
public class Train {
    private Long id;
    private String name;
    private String source;
    private String destination;
}

