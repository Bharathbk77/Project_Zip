package com.example.BookingApp.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserResponse {
    private String username;
    private String token;

    public UserResponse(String username, String token) {
        this.username = username;
        this.token = token;
    }
// Getters
}