package com.example.makemytrip.MMT.controller;

import com.example.makemytrip.MMT.dto.Passenger;
import com.example.makemytrip.MMT.dto.Ticket;
import com.example.makemytrip.MMT.dto.TicketRequest;
import com.example.makemytrip.MMT.dto.Train;
import com.example.makemytrip.MMT.service.IRCTCClientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
@RequestMapping("/mmt")
public class MmtController {

    @Autowired
    private IRCTCClientService irctcClientService;

    @GetMapping("/passengers")
    public List<Passenger> getAllPassengers() {
        return irctcClientService.getAllPassengers();
    }

    @GetMapping("/trains")
    public List<Train> getAllTrains() {
        return irctcClientService.getAllTrains();
    }

    @GetMapping("/tickets")
    public List<Ticket> getAllTickets() {
        return irctcClientService.getAllTickets();
    }

    @PostMapping("/book")
    public Ticket bookTicket(@RequestBody TicketRequest request) {
        return irctcClientService.createTicket(request);
    }
}