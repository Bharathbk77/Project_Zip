package com.quizapp.quizapp.controller;

import com.quizapp.quizapp.entity.Question;
import com.quizapp.quizapp.service.QuestionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/questions")
public class QuestionController {
    @Autowired
    private QuestionService questionService;

    @PostMapping("/add/{quizId}")
    public Question addQuestion(@PathVariable Long quizId, @RequestBody Question question){
        return questionService.addQuestionToQuiz(quizId, question);
    }
    @GetMapping("/quiz/{quizId}")
    public List<Question> getAllQuestionByQuiz(@PathVariable Long quizId){
        return questionService.getQuestionsByQuiz(quizId);
    }
    @GetMapping("/{id}")
    public  Question getQuestionById(@PathVariable Long questionId){
        return questionService.getQuestionById(questionId);
    }
}
