package com.example.makemytrip.MMT.dto;

import lombok.Data;

@Data
public class Passenger {
    private Long id;
    private String name;
    private int age;
}
