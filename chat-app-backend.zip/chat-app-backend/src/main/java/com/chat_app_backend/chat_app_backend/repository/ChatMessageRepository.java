package com.chat_app_backend.chat_app_backend.repository;

import com.chat_app_backend.chat_app_backend.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {
    // Find messages by sender
    List<ChatMessage> findBySender(String sender);

    // Find messages by receiver
    List<ChatMessage> findByReceiver(String receiver);

    // Find messages between sender and receiver
    List<ChatMessage> findBySenderAndReceiver(String sender, String receiver);
}
