package com.example.BookingApp.dto;

import lombok.Data;

@Data
public class UserRegistrationRequest {
    private String username;
    private String password;
// Getters and setters
}
