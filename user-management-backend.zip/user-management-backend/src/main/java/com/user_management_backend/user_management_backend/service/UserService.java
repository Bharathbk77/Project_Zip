package com.user_management_backend.user_management_backend.service;

import com.user_management_backend.user_management_backend.dto.UserDto;

import java.util.List;
import java.util.Optional;

public interface UserService {
    public UserDto registerUser(UserDto userDto);
    public UserDto updateUser(Long id,UserDto userDto);
    public Optional<UserDto> getUserById(Long id);
    public List<UserDto> getAllUsers();
    public void deleteUser(Long id);

}
