package com.example.IRCTC.irctc.controller;

import com.example.IRCTC.irctc.dto.TicketRequest;
import com.example.IRCTC.irctc.entity.Passenger;
import com.example.IRCTC.irctc.entity.Ticket;
import com.example.IRCTC.irctc.entity.Train;
import com.example.IRCTC.irctc.service.PassengerService;
import com.example.IRCTC.irctc.service.TicketService;
import com.example.IRCTC.irctc.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@CrossOrigin("*")  // Optional for frontend integration
@RestController
@RequestMapping("api/tickets")
public class TicketController {

    @Autowired
    private TicketService ticketService;

    @Autowired
    private PassengerService passengerService;

    @Autowired
    private TrainService trainService;

    // Create ticket with passengerId and trainId
    @PostMapping
    public Ticket saveTicket(@RequestBody TicketRequest request) {
        Passenger passenger = passengerService.getById(request.getPassengerId());
        Train train = trainService.getTrainById(request.getTrainId());

        if (passenger == null) {
            throw new RuntimeException("Passenger not found with ID: " + request.getPassengerId());
        }
        if (train == null) {
            throw new RuntimeException("Train not found with ID: " + request.getTrainId());
        }

        Ticket ticket = new Ticket();
        ticket.setStatus(request.getStatus());
        ticket.setPassenger(passenger);
        ticket.setTrain(train);

        return ticketService.saveTicket(ticket);
    }

    @GetMapping("/all")
    public List<Ticket> getAllTickets() {
        return ticketService.getAllTickets();
    }

    @GetMapping("/id/{id}")
    public Ticket getTicketById(@PathVariable Long id) {
        return ticketService.getById(id);
    }



    @GetMapping("/status/{status}")
    public Optional<Ticket> getTicketByStatus(@PathVariable String status) {
        return ticketService.getByStatus(status);
    }

    @DeleteMapping("/{id}")
    public String deleteTicket(@PathVariable Long id) {
        ticketService.deleteTicket(id);
        return "Ticket deleted with ID: " + id;
    }

    @PutMapping("/update/{id}")
    public Ticket updateTicket(@PathVariable Long id, @RequestBody Ticket ticket) {
        return ticketService.updateTicket(id, ticket);
    }
}
