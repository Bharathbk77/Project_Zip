package com.example.BookingApp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class DiscountRequest {

    private OrderDTO orderDetails;  // Add this field so constructor makes sense

    // Custom constructor
    public DiscountRequest(OrderDTO orderDetails) {
        this.orderDetails = orderDetails;
    }
}
