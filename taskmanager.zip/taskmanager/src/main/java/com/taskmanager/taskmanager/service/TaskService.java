package com.taskmanager.taskmanager.service;

import com.taskmanager.taskmanager.entity.Task;
import com.taskmanager.taskmanager.entity.User;
import com.taskmanager.taskmanager.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    @Autowired
    private TaskRepository taskRepository;

    public Task saveTask(Task task){
        return taskRepository.save(task);
    }
    public List<Task> gettaskList(){
        return taskRepository.findAll();
    }
    public Optional<Task> gettaskById(Long id){
        return taskRepository.findById(id);
    }
    public void deleteTask(Long id){
         taskRepository.deleteById(id);//here return is not used
        // because u r not returning anything after deletion
    }
//    public String deleteTask(Long id){
//        taskRepository.deleteById(id);// we can write like this
//        return "Task deleted Succesfully";
//    }

    public Task updateTask(Long id,Task task){
        Optional<Task> optionalTask=taskRepository.findById(id);

        if(optionalTask.isPresent()){
            Task t1=optionalTask.get();
            t1.setDescription(task.getDescription());
            t1.setCompleted(task.isCompleted());
            t1.setTitle(task.getTitle());
            t1.setUser(task.getUser());
            return taskRepository.save(t1);
        }
        else{
            throw new IllegalArgumentException("Can't Update the Task!");
        }

    }

}
