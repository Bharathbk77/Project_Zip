package com.quizapp.quizapp.service;

import com.quizapp.quizapp.entity.User;
import com.quizapp.quizapp.entity.UserAnswer;
import com.quizapp.quizapp.repository.UserAnswerRepository;
import com.quizapp.quizapp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserAnswerService {
    @Autowired
    private UserAnswerRepository userAnswerRepository;

    public UserAnswer saveUserAnswer(UserAnswer userAnswer){
        return userAnswerRepository.save(userAnswer);
    }
    public List<UserAnswer> getUserAnswerById(Long scoreId){
        return userAnswerRepository.findByScoreId(scoreId);
    }
    public List<UserAnswer> getAnswersByUserAndQuiz(Long userId, Long quizId) {
        return userAnswerRepository.findByScoreUserIdAndQuestionQuizId(userId, quizId);
    }

}
