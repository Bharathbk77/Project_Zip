package com.task_tracker_backend.task_tracker_backend.service;


import com.task_tracker_backend.task_tracker_backend.entity.Task;
import com.task_tracker_backend.task_tracker_backend.repository.TaskRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {
    private static final Logger log = LoggerFactory.getLogger(TaskService.class);
    @Autowired
    private TaskRepository taskRepository;

    public Task  createTask(Task task){
        log.info("Task Created Successfully");
        return taskRepository.save(task);
    }
    public List<Task> getAllTasks(){
        log.info("Tasks List Successfully");
        return taskRepository.findAll();
    }
    public Optional<Task> getTaskById(Long id){
        log.info("Task Fetch By Id Successfully");
        return taskRepository.findById(id);
    }
    public boolean deleteTask(Long id) {
        taskRepository.deleteById(id);
        log.info("Task Deleted Successfully");
        return true;
    }
    // Update an existing task
    public Task updateTask(Long id, Task task) {
        Optional<Task> existingTaskOpt = taskRepository.findById(id);

        if (existingTaskOpt.isPresent()) {
            Task existingTask = existingTaskOpt.get();

            // Update the task's fields with the new values
            existingTask.setTitle(task.getTitle());
            existingTask.setDescription(task.getDescription());
            existingTask.setCompleted(task.isCompleted());

            // Save the updated task to the repository
            log.info("Task Updated Successfully");
            return taskRepository.save(existingTask);
        }

        return null;  // Return null if task not found
    }

}
