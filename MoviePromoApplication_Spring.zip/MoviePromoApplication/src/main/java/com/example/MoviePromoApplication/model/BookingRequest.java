package com.example.MoviePromoApplication.model;

import lombok.Data;

import java.util.List;

@Data
public class BookingRequest {
    private String sessionId;
    private String profileId;
    private boolean firstTimeDownload;
    private boolean preApprovedLoan;
    private String couponCode;
    private List<CartItem> cartItems;

}
