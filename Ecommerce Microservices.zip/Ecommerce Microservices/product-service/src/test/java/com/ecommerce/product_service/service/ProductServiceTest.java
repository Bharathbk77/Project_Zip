package com.ecommerce.product_service.service;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


import com.ecommerce.product_service.dto.ProductRequest;
import com.ecommerce.product_service.dto.ProductResponse;
import com.ecommerce.product_service.entity.Category;
import com.ecommerce.product_service.entity.Product;
import com.ecommerce.product_service.repository.CategoryRepository;
import com.ecommerce.product_service.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private ProductService productService;

    private Category category;
    private Product product;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        category = Category.builder()
                .id(1L)
                .name("Electronics")
                .build();

        product = Product.builder()
                .id(100L)
                .name("iPhone 15")
                .description("Latest Apple iPhone")
                .price(BigDecimal.valueOf(999.99))
                .brand("Apple")
                .imageUrl("http://image.com/iphone.jpg")
                .category(category)
                .rating(4.5)
                .createdAt(LocalDateTime.now())
                .updatedAt(LocalDateTime.now())
                .build();
    }

    @Test
    void saveProduct_ShouldSaveAndReturnResponse() {
        ProductRequest request = ProductRequest.builder()
                .name("iPhone 15")
                .description("Latest Apple iPhone")
                .price(BigDecimal.valueOf(999.99))
                .brand("Apple")
                .imageUrl("http://image.com/iphone.jpg")
                .categoryId(1L)
                .build();

        when(categoryRepository.findById(1L)).thenReturn(Optional.of(category));
        when(productRepository.save(any(Product.class))).thenReturn(product);

        ProductResponse response = productService.saveProduct(request);

        assertNotNull(response);
        assertEquals("iPhone 15", response.getName());
        assertEquals("Electronics", response.getCategory());
        verify(categoryRepository, times(1)).findById(1L);
        verify(productRepository, times(1)).save(any(Product.class));
    }

    @Test
    void saveProduct_ShouldThrowException_WhenCategoryNotFound() {
        ProductRequest request = ProductRequest.builder()
                .name("iPhone 15")
                .categoryId(99L)
                .build();

        when(categoryRepository.findById(99L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> productService.saveProduct(request));

        assertEquals("Category not found", ex.getMessage());
        verify(productRepository, never()).save(any(Product.class));
    }

    @Test
    void getAllProducts_ShouldReturnProductList() {
        when(productRepository.findAll()).thenReturn(List.of(product));

        List<ProductResponse> responses = productService.getAllProducts();

        assertEquals(1, responses.size());
        assertEquals("iPhone 15", responses.get(0).getName());
        assertEquals("Electronics", responses.get(0).getCategory());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void getProductById_ShouldReturnProductResponse() {
        when(productRepository.findById(100L)).thenReturn(Optional.of(product));

        ProductResponse response = productService.getProductById(100L);

        assertNotNull(response);
        assertEquals(100L, response.getId());
        assertEquals("iPhone 15", response.getName());
        assertEquals("Electronics", response.getCategory());
        verify(productRepository, times(1)).findById(100L);
    }

    @Test
    void getProductById_ShouldThrowException_WhenNotFound() {
        when(productRepository.findById(200L)).thenReturn(Optional.empty());

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> productService.getProductById(200L));

        assertEquals("Product not found", ex.getMessage());
        verify(productRepository, times(1)).findById(200L);
    }
}
