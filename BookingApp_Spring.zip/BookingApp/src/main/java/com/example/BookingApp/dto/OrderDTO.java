package com.example.BookingApp.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class OrderDTO {

    private Long id;

    @NotNull
    private LocalDateTime orderDate;

    private Long userId;

    private List<ProductDTO> products;

    private Double totalPrice;

    private Double discountPrice;

// Getters and Setters
}
