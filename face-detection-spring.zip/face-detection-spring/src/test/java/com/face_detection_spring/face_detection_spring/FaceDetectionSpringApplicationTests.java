package com.face_detection_spring.face_detection_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaceDetectionSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
