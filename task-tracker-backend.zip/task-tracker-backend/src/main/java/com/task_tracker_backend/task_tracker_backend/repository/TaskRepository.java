package com.task_tracker_backend.task_tracker_backend.repository;

import com.task_tracker_backend.task_tracker_backend.entity.Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task,Long> {

}
