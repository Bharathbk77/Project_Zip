//package com.example.MoviePromoApplication.service;
//
//import com.example.MoviePromoApplication.model.BookingRequest;
//import com.example.MoviePromoApplication.model.CartItem;
//import com.example.MoviePromoApplication.model.EffectResult;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import lombok.SneakyThrows;
//import org.springframework.http.HttpEntity;
//import org.springframework.http.HttpHeaders;
//import org.springframework.http.HttpMethod;
//import org.springframework.http.ResponseEntity;
//import org.springframework.stereotype.Service;
//import org.springframework.web.client.RestTemplate;
//import com.example.MoviePromoApplication.model.*;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import  com.example.MoviePromoApplication.model.BookingResponse;
//@Service
//public class TalonOneService {

//    private final String TALONONE_API = "https://demo.talon.one/v1/customer_sessions/";
//    private final String API_KEY = "demo123456"; // dummy for testing
//
//    @SneakyThrows
//    public Object applyPromotions(BookingRequest request) {
//
//        // Build payload
//        Map<String, Object> session = new HashMap<>();
//        session.put("profileId", request.getProfileId());
//
//        // Convert cart items
//        List<Map<String, Object>> items = new ArrayList<>();
//        for (CartItem item : request.getCartItems()) {
//            Map<String, Object> i = new HashMap<>();
//            i.put("name", item.getName());
//            i.put("quantity", item.getQuantity());
//            i.put("price", item.getPrice());
//            items.add(i);
//        }
//
//        session.put("cartItems", items);
//
//        // Custom attributes
//        Map<String, Object> attrs = new HashMap<>();
//        attrs.put("firstTimeDownload", request.isFirstTimeDownload());
//        attrs.put("preApprovedLoan", request.isPreApprovedLoan());
//        session.put("attributes", attrs);
//
//        // Apply coupon
//        if (request.getCouponCode() != null && !request.getCouponCode().isEmpty()) {
//            session.put("coupon", request.getCouponCode());
//        }
//
//        // Prepare request
//        RestTemplate restTemplate = new RestTemplate();
//        HttpHeaders headers = new HttpHeaders();
//        headers.set("Authorization", "ApiKey-v1 " + API_KEY);
//        headers.set("Content-Type", "application/json");
//
//        HttpEntity<String> entity = new HttpEntity<>(new ObjectMapper().writeValueAsString(session), headers);
//
//        // Call Talon.One API (PUT)
//        ResponseEntity<Object> response = restTemplate.exchange(
//                TALONONE_API + request.getSessionId(), HttpMethod.PUT, entity, Object.class
//        );
//
//        return response.getBody();
//    }
//
//public BookingResponse applyPromotions(BookingRequest request) {
//    double originalTotal = 0;
//    for (CartItem item : request.getCartItems()) {
//        originalTotal += item.getPrice() * item.getQuantity();
//    }
//
//    double discount = 0;
//    List<EffectResult> effects = new ArrayList<>();
//
//    // Simulate rule: 50% off if coupon is "50OFF"
//    if ("50OFF".equalsIgnoreCase(request.getCouponCode())) {
//        discount = originalTotal * 0.5;
//        effects.add(new EffectResult("setDiscount", discount, "50% off using coupon " + request.getCouponCode()));
//    }
//
//    // Simulate rule: add loyalty points if firstTimeDownload
//    if (request.isFirstTimeDownload()) {
//        effects.add(new EffectResult("addLoyaltyPoints", 10, "You earned 10 loyalty points"));
//    }
//
//    double finalTotal = originalTotal - discount;
//
//    return new BookingResponse(originalTotal, finalTotal, effects);
//}
//}




package com.example.MoviePromoApplication.service;

import com.example.MoviePromoApplication.model.BookingRequest;
import com.example.MoviePromoApplication.model.CartItem;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

@Service
public class TalonOneService {

    @Value("${talonone.api.key}")
    private String apiKey;

    @Value("${talonone.api.url}")
    private String apiUrl;

    @SneakyThrows
    public Object applyPromotions(BookingRequest request) {
        // Prepare session data
        Map<String, Object> session = new HashMap<>();
        session.put("profileId", request.getProfileId());

        List<Map<String, Object>> items = new ArrayList<>();
        for (CartItem item : request.getCartItems()) {
            Map<String, Object> itemMap = new HashMap<>();
            itemMap.put("name", item.getName());
            itemMap.put("quantity", item.getQuantity());
            itemMap.put("price", item.getPrice());
            items.add(itemMap);
        }
        session.put("cartItems", items);

        Map<String, Object> attributes = new HashMap<>();
        attributes.put("firstTimeDownload", request.isFirstTimeDownload());
        attributes.put("preApprovedLoan", request.isPreApprovedLoan());
        session.put("attributes", attributes);

        if (request.getCouponCode() != null && !request.getCouponCode().isEmpty()) {
            session.put("coupon", request.getCouponCode());
        }

        // Set headers
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "ApiKey-v1 " + apiKey);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<String> entity = new HttpEntity<>(new ObjectMapper().writeValueAsString(session), headers);

        // Make the PUT call to Talon.One
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Object> response = restTemplate.exchange(
                apiUrl + request.getSessionId(),
                HttpMethod.PUT,
                entity,
                Object.class
        );

        return response.getBody();
    }
}
