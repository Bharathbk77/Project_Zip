package com.example.BookingApp.repository;

import com.example.BookingApp.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserId(Long userId);
    List<Order> findByStatus(String status);
    List<Order> findByCreatedAtAfter(LocalDateTime createdAt);
    List<Order> findByCreatedAtBefore(LocalDateTime createdAt);
    List<Order> findByTotalAmountGreaterThan(BigDecimal totalAmount);
    List<Order> findByTotalAmountLessThan(BigDecimal totalAmount);

    @Query("SELECT o FROM Order o JOIN o.products p WHERE p.id = :productId")
    List<Order> findByProductId(@Param("productId") Long productId);
}
