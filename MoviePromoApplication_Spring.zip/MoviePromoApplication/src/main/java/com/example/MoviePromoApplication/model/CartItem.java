package com.example.MoviePromoApplication.model;

import lombok.Data;

@Data
public class CartItem {
    private String name;
    private int quantity;
    private double price;
}
