package com.quizapp.quizapp.service;

import com.quizapp.quizapp.entity.Quiz;
import com.quizapp.quizapp.repository.QuizRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QuizService {
    @Autowired
    private QuizRepository quizRepository;

    public Quiz createOrUpdate(Quiz quiz){
        return quizRepository.save(quiz);
    }

    public Quiz getQuizById(Long id) {
        return quizRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Quiz not found with id: " + id));
    }

    public List<Quiz> getAllQuizzes() {
        return quizRepository.findAll();
    }
}
