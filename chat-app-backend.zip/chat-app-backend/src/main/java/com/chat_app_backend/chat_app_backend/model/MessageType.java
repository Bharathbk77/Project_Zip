package com.chat_app_backend.chat_app_backend.model;

public enum MessageType {
    CHAT,     // Regular chat message
    JOIN,     // When a user joins the chat
    LEAVE     // When a user leaves the chat
}
