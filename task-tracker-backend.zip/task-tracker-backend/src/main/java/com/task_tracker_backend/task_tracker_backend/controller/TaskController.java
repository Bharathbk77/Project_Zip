package com.task_tracker_backend.task_tracker_backend.controller;

import com.task_tracker_backend.task_tracker_backend.entity.Task;
import com.task_tracker_backend.task_tracker_backend.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
@RequestMapping("api/tasks")
public class TaskController {
    @Autowired
    private  TaskService taskService;

    @GetMapping("/hello")
    public String hello(){
        return "Hello BK";
    }
    // Add a new task
    @PostMapping("/add")
    public Task createTask(@RequestBody Task task) {
        return taskService.createTask(task);
    }
    // Get all tasks
    @GetMapping("/all")
    public List<Task> getAllTasks() {
        return taskService.getAllTasks();
    }

    // Get a task by ID
    @GetMapping("/{id}")
    public Optional<Task> getTaskById(@PathVariable("id") Long id) {
        return taskService.getTaskById(id);
    }

    // Update an existing task
    @PutMapping("/{id}")
    public ResponseEntity<Task> updateTask(@PathVariable("id") Long id, @RequestBody Task task) {
        Task updatedTask = taskService.updateTask(id, task);
        if (updatedTask != null) {
            return new ResponseEntity<>(updatedTask, HttpStatus.OK); // Return 200 if task updated
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Return 404 if task not found
    }

    // Delete a task by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable("id") Long id) {
        boolean isDeleted = taskService.deleteTask(id);
        if (isDeleted) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT); // Return 204 if task deleted
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND); // Return 404 if task not found
    }

}