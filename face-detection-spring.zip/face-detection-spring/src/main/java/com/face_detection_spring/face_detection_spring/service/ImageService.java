package com.face_detection_spring.face_detection_spring.service;

import com.face_detection_spring.face_detection_spring.entity.Image;
import com.face_detection_spring.face_detection_spring.repository.ImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.awt.*;
import java.io.IOException;
import java.io.InputStream;

@Service
public class ImageService {

    @Autowired
    private ImageRepository imageRepository;

    // Method to store image into database
    public void storeImage(MultipartFile file) throws IOException {
        InputStream inputStream = file.getInputStream();

        // Convert the file input stream into a byte array
        byte[] fileData = inputStream.readAllBytes();

        // Create a new Image entity and store the byte array
        Image image = new Image();
        image.setName(file.getOriginalFilename());
        image.setData(fileData);

        // Save the image into the database
        imageRepository.save(image);
    }
}