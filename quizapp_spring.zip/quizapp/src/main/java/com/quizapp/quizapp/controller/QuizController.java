package com.quizapp.quizapp.controller;

import com.quizapp.quizapp.entity.Quiz;
import com.quizapp.quizapp.service.QuizService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/quizzes")
public class QuizController {
    @Autowired
    private QuizService quizService;

    @PostMapping("/create")
    public Quiz createQuiz(@RequestBody Quiz quiz){
        return quizService.createOrUpdate(quiz);
    }
    @GetMapping("/all")
    public List<Quiz> getAllQuizzes(){
        return quizService.getAllQuizzes();
    }
    @GetMapping("/{id}")
    public Quiz getQuizById(@PathVariable Long id) {
        return quizService.getQuizById(id);
    }
}
