package com.quizapp.quizapp.controller;

import com.quizapp.quizapp.entity.UserAnswer;
import com.quizapp.quizapp.service.UserAnswerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/useranswers")
public class UserAnswerController {
    @Autowired
    private UserAnswerService userAnswerService;

    @PostMapping("/submit")
    public UserAnswer submitAnswer(@RequestBody UserAnswer userAnswer){
        return userAnswerService.saveUserAnswer(userAnswer);
    }
    @GetMapping("/user/{userId}/quiz/{quizId}")
    public List<UserAnswer> getAnswersByUserAndQuiz(@PathVariable Long userId, @PathVariable Long quizId){
        return userAnswerService.getAnswersByUserAndQuiz(userId, quizId);
    }

}
