package com.FirstProject.BaiscProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BaiscProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
