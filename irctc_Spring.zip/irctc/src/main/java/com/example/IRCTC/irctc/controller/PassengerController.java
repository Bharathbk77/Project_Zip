package com.example.IRCTC.irctc.controller;

import com.example.IRCTC.irctc.entity.Passenger;
import com.example.IRCTC.irctc.service.PassengerService;
import org.aspectj.lang.annotation.DeclareError;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/passengers")
public class PassengerController {

    @Autowired
    PassengerService passengerService;

    @PostMapping
    public Passenger savePassenger(@RequestBody Passenger passenger){
        return passengerService.savePassenger(passenger);
    }
    @GetMapping("/all")
    public List<Passenger> getAllPassenger(){
        return  passengerService.getallPassengers();
    }
    @GetMapping("/Id/{id}")
    public Passenger getById(@PathVariable Long id){
        return passengerService.getById(id);
    }
    @GetMapping("/name/{name}")
    public Passenger getByName(@PathVariable String name){
        return  passengerService.getByName(name);
    }
    @PutMapping("update/{id}")
    public Passenger updateById(@PathVariable Long id,@RequestBody Passenger passenger){
        return passengerService.updatePassenger(id, passenger);
    }
    @DeleteMapping("/id/{id}")
    public String deletePassenger(@PathVariable Long id) {
        passengerService.deletePassengerById(id);
        return "Passenger deleted with ID: " + id;
    }
}
