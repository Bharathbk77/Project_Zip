package com.quizapp.quizapp.repository;

import com.quizapp.quizapp.entity.Question;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QuestionRepository extends JpaRepository<Question,Long> {
    List<Question> findByQuizId(Long quizId);// fetch all questions of a quiz
}
