package com.example.BookingApp.service;

import com.example.BookingApp.dto.DiscountRequest;
import com.example.BookingApp.dto.DiscountResponse;
import com.example.BookingApp.dto.OrderDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class TalonOneService {

    @Value("${talon.one.base-url}")
    private String baseUrl;

    @Value("${talon.one.api-key}")
    private String apiKey;

    private final RestTemplate restTemplate;

    public TalonOneService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public double evaluateDiscount(OrderDTO orderDetails) {
        String url = baseUrl + "/discounts";
        DiscountRequest discountRequest = new DiscountRequest(orderDetails);
        DiscountResponse discountResponse = restTemplate.postForObject(url, discountRequest, DiscountResponse.class);
        return discountResponse.getDiscountAmount();
    }
}
