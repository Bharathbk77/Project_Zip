package com.example.IBSBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IbsBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(IbsBankApplication.class, args);
		System.out.println("Application is Running...");
	}

}
