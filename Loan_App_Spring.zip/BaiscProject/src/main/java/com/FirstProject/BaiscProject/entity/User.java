package com.FirstProject.BaiscProject.entity;

import jakarta.persistence.*;
import lombok.*;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String email;
    private String panNo;
    private double salary;
    private String employmentStatus;

    public void setId(Long id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPanNo(String panNo) {
        this.panNo = panNo;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public void setEmploymentStatus(String employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPanNo() {
        return panNo;
    }

    public double getSalary() {
        return salary;
    }

    public String getEmploymentStatus() {
        return employmentStatus;
    }

}