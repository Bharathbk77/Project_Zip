package com.example.BookingApp.service;

import com.example.BookingApp.config.JwtUtil;
import com.example.BookingApp.dto.UserLoginRequest;
import com.example.BookingApp.dto.UserRegistrationRequest;
import com.example.BookingApp.dto.UserResponse;
import com.example.BookingApp.entity.User;
import com.example.BookingApp.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Autowired
    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public UserResponse registerUser(UserRegistrationRequest request) {
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new IllegalArgumentException("Username already exists");
        }
        String hashedPassword = passwordEncoder.encode(request.getPassword());
        User user = new User();
        user.setName(request.getUsername());
        user.setPassword(hashedPassword);
        userRepository.save(user);
        return null;
    }

    public String authenticateUser(UserLoginRequest loginRequestDto) {
        // Validate credentials
        User user = userRepository.findByEmail(loginRequestDto.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));

        if (!passwordEncoder.matches(loginRequestDto.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        // Generate JWT Token
        return jwtUtil.generateToken(user.getEmail());
    }

}
