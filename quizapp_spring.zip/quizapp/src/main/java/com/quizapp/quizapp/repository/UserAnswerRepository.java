package com.quizapp.quizapp.repository;

import com.quizapp.quizapp.entity.UserAnswer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

public interface UserAnswerRepository extends JpaRepository<UserAnswer,Long> {
    List<UserAnswer> findByScoreId(Long scoreId); // get answers of a quiz attempt

//    List<UserAnswer> findByUserIdAndQuizId(Long userId, Long quizId);
    List<UserAnswer> findByScoreUserIdAndQuestionQuizId(Long userId, Long quizId);

}
