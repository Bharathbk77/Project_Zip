package com.quizapp.quizapp.repository;

import com.quizapp.quizapp.entity.Score;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ScoreRepository extends JpaRepository<Score, Long> {
    List<Score> findByUserId(Long userId);// get scores for a specific user
    List<Score> findTop10ByQuizIdOrderByScoreDesc(Long quizId);
}
