package com.example.IRCTC.irctc.controller;

import com.example.IRCTC.irctc.entity.Train;
import com.example.IRCTC.irctc.service.TrainService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/trains")
public class TrainController {

    @Autowired
    private TrainService trainService;

    @PostMapping
    public Train saveTrain(@RequestBody Train train) {
        return trainService.saveTrain(train);
    }

    @GetMapping("/all")
    public List<Train> getAllTrains() {
        return trainService.getAllTrains();
    }

    @GetMapping("/id/{id}")
    public Train getTrainById(@PathVariable Long id) {
        return trainService.getTrainById(id);
    }

    @PutMapping("/update/{id}")
    public Train updateTrain(@PathVariable Long id, @RequestBody Train train) {
        return trainService.updateTrain(id, train);
    }

    @DeleteMapping("/delete/{id}")
    public String deleteTrain(@PathVariable Long id) {
        trainService.deleteTrain(id);
        return "Train deleted with ID: " + id;
    }
}
