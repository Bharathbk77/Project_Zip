package com.ecommerce.product_service.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "AUTH-SERVICE", url = "http://localhost:8081/auth")
public interface AuthClient {
    @GetMapping("/users/{id}")
    Boolean userExists(@PathVariable("id") Long id);
}