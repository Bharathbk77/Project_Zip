package com.face_detection_spring.face_detection_spring.repository;

import com.face_detection_spring.face_detection_spring.entity.Image;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ImageRepository extends JpaRepository<Image, Long> {
}
