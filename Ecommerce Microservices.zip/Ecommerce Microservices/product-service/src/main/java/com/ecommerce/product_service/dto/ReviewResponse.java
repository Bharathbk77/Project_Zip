package com.ecommerce.product_service.dto;


import lombok.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class ReviewResponse {
    private Long id;
    private Long productId;
    private int rating;
    private String comment;
}
