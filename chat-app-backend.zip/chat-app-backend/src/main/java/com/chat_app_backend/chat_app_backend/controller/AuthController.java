package com.chat_app_backend.chat_app_backend.controller;

import com.chat_app_backend.chat_app_backend.model.User;
import com.chat_app_backend.chat_app_backend.service.JwtService;
import com.chat_app_backend.chat_app_backend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    @Autowired
    private JwtService jwtService;


    // Register a new user
    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        // You can add checks here for existing username/email before saving
        User savedUser = userService.registerUser(user);
        return ResponseEntity.ok(savedUser);
    }

    // Login and generate JWT token
    @PostMapping("/login")
    public ResponseEntity<?> loginUser(@RequestBody User user) {
        Optional<User> existingUser = userService.findByUsername(user.getUsername());

        if (existingUser.isPresent()) {
            User foundUser = existingUser.get();

            // Very basic password check, ideally use hashed passwords!
            if (foundUser.getPassword().equals(user.getPassword())) {
                // Generate JWT token
                String token = jwtService.generateToken(foundUser.getUsername());
                return ResponseEntity.ok(token);
            }
        }
        return ResponseEntity.status(401).body("Invalid username or password");
    }
}
