package com.example.makemytrip.MMT.dto;

import lombok.Data;

@Data
public class Ticket {
    private Long id;
    private Passenger passenger;
    private Train train;
    private String status;
}
