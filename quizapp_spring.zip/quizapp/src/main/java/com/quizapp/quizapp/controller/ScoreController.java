package com.quizapp.quizapp.controller;

import com.quizapp.quizapp.entity.Score;
import com.quizapp.quizapp.service.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/scores")
public class ScoreController {
    @Autowired
    private ScoreService scoreService;

    @PostMapping("/submit")
    public Score submitScore(@RequestBody Score score){
        return scoreService.saveScore(score);
    }
    @GetMapping("/user/{userId}")
    public List<Score> getUserScores(@PathVariable Long userId){
        return scoreService.getScoreByUser(userId);
    }
    @GetMapping("/quiz/{quiId}")
    public List<Score> getScoreByQuizId(@PathVariable Long quizId){
        return scoreService.getScoresByQuiz(quizId);
    }
    // Get leaderboard (top scores for a quiz)
    @GetMapping("/quiz/{quizId}/leaderboard")
    public List<Score> getLeaderboard(@PathVariable Long quizId) {
        return scoreService.getLeaderboardByQuiz(quizId);
    }

}
