package com.example.IRCTC.irctc.service;

import com.example.IRCTC.irctc.entity.Train;
import com.example.IRCTC.irctc.repository.TrainRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TrainService {

    @Autowired
    private TrainRepository trainRepository;

    public Train saveTrain(Train train) {
        return trainRepository.save(train);
    }

    public List<Train> getAllTrains() {
        return trainRepository.findAll();
    }

    public Train getTrainById(Long id) {
        return trainRepository.findById(id).orElse(null);
    }

    public Train updateTrain(Long id, Train updatedTrain) {
        Train existing = trainRepository.findById(id).orElse(null);
        if (existing != null) {
            existing.setTrainName(updatedTrain.getTrainName());
            existing.setTrainNumber(updatedTrain.getTrainNumber());
            existing.setFromStation(updatedTrain.getFromStation());
            existing.setToStation(updatedTrain.getToStation());
            return trainRepository.save(existing);
        }
        return null;
    }

    public void deleteTrain(Long id) {
        trainRepository.deleteById(id);
    }
}
