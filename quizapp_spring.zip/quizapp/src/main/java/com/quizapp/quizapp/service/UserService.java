//package com.quizapp.quizapp.service;
//
//import com.quizapp.quizapp.entity.User;
//import com.quizapp.quizapp.repository.UserRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class UserService {
//    @Autowired
//    private UserRepository userRepository;
//
//    public User registerUser(User user) {
//        Optional<User> existingUserByEmail = userRepository.findByEmail(user.getEmail());
//        if (existingUserByEmail.isPresent()) {
//            throw new RuntimeException("Email already exists"); // Now correctly prevents duplicates
//        }
//        user.setId(null);
//        return userRepository.save(user); // This will ALWAYS create a new user if the email is unique
//    }
//
//    public User findByUser(String name){
//        return userRepository.findByName(name);
//    }
//    public List<User> getAllUsers() {
//        return userRepository.findAll();
//    }
//
//}

package com.quizapp.quizapp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.quizapp.quizapp.entity.User;
import com.quizapp.quizapp.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public Optional<User> getUserByName(String name) {
        return userRepository.findByName(name);
    }

    public Optional<User> getUserByEmail(String email) {
        return userRepository.findByEmail(email);
    }

    public User registerUser(User user) throws Exception {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            throw new Exception("Email already registered");
        }
        return userRepository.save(user);
    }
}
