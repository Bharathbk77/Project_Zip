package com.jwtauth.jwt_auth_demo.service;


import com.jwtauth.jwt_auth_demo.model.User;
import com.jwtauth.jwt_auth_demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public boolean validateUser(String username, String password) {
        Optional<User> user = userRepository.findById(username);
        return user.isPresent() && user.get().getPassword().equals(password);
    }

    public List<SimpleGrantedAuthority> getAuthorities(String username) {
        return List.of(new SimpleGrantedAuthority("ROLE_USER"));
    }
}

