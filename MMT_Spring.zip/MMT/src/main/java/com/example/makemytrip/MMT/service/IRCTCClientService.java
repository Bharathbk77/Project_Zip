package com.example.makemytrip.MMT.service;

import com.example.makemytrip.MMT.dto.Passenger;
import com.example.makemytrip.MMT.dto.Ticket;
import com.example.makemytrip.MMT.dto.TicketRequest;
import com.example.makemytrip.MMT.dto.Train;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.List;

@Service
public class IRCTCClientService {

    @Autowired
    private RestTemplate restTemplate;

    private final String BASE_URL = "http://localhost:8080/api";

    public List<Passenger> getAllPassengers() {
        Passenger[] passengers = restTemplate.getForObject(BASE_URL + "/passengers/all", Passenger[].class);
        return Arrays.asList(passengers);
    }

    public List<Train> getAllTrains() {
        Train[] trains = restTemplate.getForObject(BASE_URL + "/trains/all", Train[].class);
        return Arrays.asList(trains);
    }

    public List<Ticket> getAllTickets() {
        Ticket[] tickets = restTemplate.getForObject(BASE_URL + "/tickets/all", Ticket[].class);
        return Arrays.asList(tickets);
    }

    public Ticket createTicket(TicketRequest request) {
        return restTemplate.postForObject(BASE_URL + "/tickets", request, Ticket.class);
    }
}
