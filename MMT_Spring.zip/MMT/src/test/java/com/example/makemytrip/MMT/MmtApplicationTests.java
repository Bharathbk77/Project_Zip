package com.example.makemytrip.MMT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
