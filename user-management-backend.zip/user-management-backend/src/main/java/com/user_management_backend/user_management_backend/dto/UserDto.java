package com.user_management_backend.user_management_backend.dto;

import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserDto {
    private Long id;
    private String username;
    private String password;
    private String role;

    public UserDto(Long id, String username, String role) {
        this.id=id;
        this.username=username;
        this.role=role;
    }
}
