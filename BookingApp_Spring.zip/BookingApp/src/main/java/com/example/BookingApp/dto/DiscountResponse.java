package com.example.BookingApp.dto;

import lombok.Data;

@Data
public class DiscountResponse {
    double discountAmount;

}
