package com.example.IRCTC.irctc.repository;

import com.example.IRCTC.irctc.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TicketRepository extends JpaRepository<Ticket, Long> {

    // A ticket doesn't have a name, so remove getByName if not needed
    Optional<Ticket> findByStatus(String status);
}
