package com.example.BookingApp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderRequestDto {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotNull(message = "Product IDs list cannot be null")
    private List<Long> productIds;

    @NotNull(message = "Total amount is required")
    @Positive(message = "Total amount must be greater than zero")
    private BigDecimal totalAmount;

    private String discountCode; // Optional, for applying discounts

    // ✅ Optional helper method if needed for backward compatibility
    public List<Long> getProducts() {
        return this.productIds;
    }
}
