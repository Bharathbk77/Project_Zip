package com.example.MoviePromoApplication.controller;


import com.example.MoviePromoApplication.model.BookingRequest;
import com.example.MoviePromoApplication.service.TalonOneService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/book")
@RequiredArgsConstructor
public class BookingController {

    private final TalonOneService talonOneService;
    @GetMapping("/test")
    public String test() {
        return "Controller is working!";
    }

    @PostMapping("/applyPromotions")
    public Object processBooking(@RequestBody BookingRequest request) {
        return talonOneService.applyPromotions(request);
    }
}