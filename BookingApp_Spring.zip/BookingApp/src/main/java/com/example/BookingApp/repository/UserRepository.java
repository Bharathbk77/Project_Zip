package com.example.BookingApp.repository;

import com.example.BookingApp.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByFirstName(String firstName);
    List<User> findByLastName(String lastName);
    List<User> findByRole(String role);
    boolean existsByEmail(String email);
    List<User> findByCreatedAtAfter(LocalDateTime createdAt);
    List<User> findByEmailContaining(String keyword);
    boolean existsByUsername(String name);
    Optional<User> findByUsername(String name);
}
