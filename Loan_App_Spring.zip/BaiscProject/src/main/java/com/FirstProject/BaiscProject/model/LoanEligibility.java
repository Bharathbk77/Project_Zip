    package com.FirstProject.BaiscProject.model;



    import lombok.*;
    import java.util.List;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public class LoanEligibility {
        private String userName;
        private int score;
        private String eligibilityStatus;
        private List<String> eligibleLoans;
        private String message;

        public String getUserName() {
            return userName;
        }

        public String getEligibilityStatus() {
            return eligibilityStatus;
        }

        public String getMessage() {
            return message;
        }

        public List<String> getEligibleLoans() {
            return eligibleLoans;
        }

        public int getScore() {
            return score;
        }

        public void setScore(int score) {
            this.score = score;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public void setEligibilityStatus(String eligibilityStatus) {
            this.eligibilityStatus = eligibilityStatus;
        }

        public void setEligibleLoans(List<String> eligibleLoans) {
            this.eligibleLoans = eligibleLoans;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }