package com.example.IRCTC.irctc.controller;

import static org.junit.jupiter.api.Assertions.*;

class PassengerControllerTest {

}