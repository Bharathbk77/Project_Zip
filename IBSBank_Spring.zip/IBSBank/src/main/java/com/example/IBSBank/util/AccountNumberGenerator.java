package com.example.IBSBank.util;

import java.util.UUID;

public class AccountNumberGenerator {
    public static String generate(){
        String uuid= UUID.randomUUID().toString().replaceAll("[^0-9]","");
        return "IBS"+uuid.substring(0,10);
    }
}
