package com.ecommerce.auth_service.controller;

import com.ecommerce.auth_service.dto.*;
import com.ecommerce.auth_service.entity.User;
import com.ecommerce.auth_service.repository.UserRepository;
import com.ecommerce.auth_service.service.AuthService;
import com.ecommerce.auth_service.service.EmailService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;
import com.ecommerce.auth_service.security.JwtUtil;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class AuthController {

    private final AuthService authService;
    private final EmailService emailService;
    private final UserRepository userRepository;
    private final JwtUtil jwtUtil;


    @PostMapping("/register")
    public String register(@RequestBody RegisterRequest request) {
        return authService.register(request);
    }

    @PostMapping("/login")
    public AuthResponse login(@RequestBody LoginRequest request) {
        return authService.login(request);
    }

    @PutMapping("/change-password/{email}")
    public String changePassword(@PathVariable String email, @RequestBody ChangePasswordRequest request) {
        return authService.changePassword(email, request);
    }

    @GetMapping("/me/{email}")
    public User getProfile(@PathVariable String email) {
        return authService.getUserDetails(email);
    }

    @GetMapping("/users/{id}")
    public Boolean userExists(@PathVariable Long id) {
        return authService.userExists(id);
    }
    @GetMapping("/test-email")
    public String testEmail(@RequestParam String email) {
        // Try to fetch user from database using provided email
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("User not found with email: " + email));

        // Send welcome email with user data
        emailService.sendWelcomeEmail(
                user.getEmail(),
                user.getName(),
                user.getPassword()  // WARNING: only if you store raw password (not recommended)
        );

        return "Test email sent to " + email;
    }


}