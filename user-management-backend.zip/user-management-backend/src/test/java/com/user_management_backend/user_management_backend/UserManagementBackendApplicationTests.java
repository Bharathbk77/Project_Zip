package com.user_management_backend.user_management_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
