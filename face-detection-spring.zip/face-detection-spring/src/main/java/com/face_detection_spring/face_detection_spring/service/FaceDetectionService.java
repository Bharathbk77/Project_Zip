package com.face_detection_spring.face_detection_spring.service;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;
import org.springframework.stereotype.Service;

@Service
public class FaceDetectionService {
    static {
        try {
            System.load("C:\\Users\\bharath.bobbali\\Downloads\\opencv\\build\\java\\x64\\opencv_java4110.dll");
        } catch (UnsatisfiedLinkError e) {
            System.err.println("Native code library failed to load: " + e);
        }
    }

    public String detectFaces(String inputPath, String outputPath) {
        CascadeClassifier faceDetector = new CascadeClassifier("src/main/resources/haarcascade_frontalface_alt.xml");

        Mat image = Imgcodecs.imread(inputPath);
        if (image.empty()) {
            return "Image not found!";
        }

        MatOfRect faceDetections = new MatOfRect();
        faceDetector.detectMultiScale(image, faceDetections);

        for (Rect rect : faceDetections.toArray()) {
            Imgproc.rectangle(image, new Point(rect.x, rect.y),
                    new Point(rect.x + rect.width, rect.y + rect.height),
                    new Scalar(0, 255, 0));
        }

        Imgcodecs.imwrite(outputPath, image);

        return "Detected " + faceDetections.toArray().length + " face(s). Saved to " + outputPath;
    }


}
