package com.example.IRCTC.irctc.service;

import com.example.IRCTC.irctc.entity.Ticket;
import com.example.IRCTC.irctc.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    public Ticket saveTicket(Ticket ticket) {
        return ticketRepository.save(ticket);
    }

    public List<Ticket> getAllTickets() {
        return ticketRepository.findAll();
    }

    public Ticket getById(Long id) {
        return ticketRepository.findById(id).orElse(null);
    }

    public Optional<Ticket> getByStatus(String status) {
        return ticketRepository.findByStatus(status);
    }

    public void deleteTicket(Long id) {
        ticketRepository.deleteById(id);
    }

    public Ticket updateTicket(Long id, Ticket updatedTicket) {
        return ticketRepository.findById(id).map(existing -> {
            existing.setStatus(updatedTicket.getStatus());
            existing.setPassenger(updatedTicket.getPassenger());
            existing.setTrain(updatedTicket.getTrain());
            return ticketRepository.save(existing);
        }).orElse(null);
    }
}
