package com.example.IBSBank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IbsBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
