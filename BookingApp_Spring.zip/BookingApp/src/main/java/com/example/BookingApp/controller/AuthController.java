package com.example.BookingApp.controller;

import com.example.BookingApp.dto.UserLoginRequest;
import com.example.BookingApp.dto.UserRegistrationRequest;
import com.example.BookingApp.dto.UserResponse;
import com.example.BookingApp.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;



/**
 * AuthController handles user authentication and registration endpoints.
 */
@RestController
@RequestMapping("/auth")
public class AuthController {

    private final AuthService authService;

    @Autowired
    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    /**
     * Endpoint for registering a new user.
     *
     * @param registrationRequestDto DTO containing user registration details.
     * @return ResponseEntity with the registered user details and HTTP status 201 CREATED.
     */
    @PostMapping("/register")
    public ResponseEntity<UserResponse> registerUser(
            @Valid @RequestBody UserRegistrationRequest registrationRequestDto) {
        UserResponse registeredUser = authService.registerUser(registrationRequestDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }

    /**
     * Endpoint for authenticating a user and returning a JWT token.
     *
     * @param loginRequestDto DTO containing user login credentials.
     * @return ResponseEntity with the JWT token and HTTP status 200 OK.
     */
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(
            @Valid @RequestBody UserLoginRequest loginRequestDto) {
        String jwtToken = authService.authenticateUser(loginRequestDto);
        return ResponseEntity.ok(jwtToken);
    }
}
