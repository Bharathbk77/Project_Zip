package com.example.IRCTC.irctc.exception;

public class GlobalExceptionHandler {
}
