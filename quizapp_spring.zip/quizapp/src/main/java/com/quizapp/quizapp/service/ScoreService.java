package com.quizapp.quizapp.service;

import com.quizapp.quizapp.entity.Score;
import com.quizapp.quizapp.repository.ScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScoreService {
    @Autowired
    private ScoreRepository scoreRepository;

    public Score saveScore(Score score){
        return scoreRepository.save(score);
    }
    public List<Score> getScoreByUser(Long userId){
        return scoreRepository.findByUserId(userId);
    }
    public List<Score> getScoresByQuiz(Long quizId){
        return  scoreRepository.findByUserId(quizId);
    }
    public List<Score> getLeaderboardByQuiz(Long quizId) {
        return scoreRepository.findTop10ByQuizIdOrderByScoreDesc(quizId);
    }
}
