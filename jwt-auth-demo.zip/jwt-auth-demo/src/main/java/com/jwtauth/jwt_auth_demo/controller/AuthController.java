package com.jwtauth.jwt_auth_demo.controller;


import com.jwtauth.jwt_auth_demo.service.UserService;
import com.jwtauth.jwt_auth_demo.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
public class AuthController {

    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password) {
        if (userService.validateUser(username, password)) {
            return jwtUtil.generateToken(username);
        } else {
            return "Invalid credentials!";
        }
    }

    @GetMapping("/protected")
    public String protectedEndpoint() {
        return "This is a protected resource!";
    }
}
