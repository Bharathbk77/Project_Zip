package com.movie_api.movie_api.controller;

import com.movie_api.movie_api.model.Movie;
import com.movie_api.movie_api.service.MovieService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import io.swagger.v3.oas.annotations.Operation;

@RestController
@RequestMapping("api/movies")
public class MovieController {

    @Autowired
    private MovieService movieService;

    @GetMapping("/all")
    @Operation(summary = "Get all movies")
    public List<Movie> getAllMovies() {
        return movieService.getAllMovies();
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get a movie by ID")
    public Movie getMovieById(@PathVariable int id) {
        return movieService.getMovieById(id);
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete a movie by ID")
    public Movie deleteById(@PathVariable int id) {
        return movieService.deleteMovie(id);
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update a movie by ID")
    public Movie updateMovie(@PathVariable int id, @RequestBody Movie movie) {
        return movieService.updateMovie(id, movie);
    }
}

