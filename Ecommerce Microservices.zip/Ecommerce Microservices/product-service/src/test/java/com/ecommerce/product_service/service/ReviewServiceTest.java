package com.ecommerce.product_service.service;

import static org.junit.jupiter.api.Assertions.*;

import com.ecommerce.product_service.dto.ReviewRequest;
import com.ecommerce.product_service.dto.ReviewResponse;
import com.ecommerce.product_service.entity.Product;
import com.ecommerce.product_service.entity.Review;
import com.ecommerce.product_service.repository.ProductRepository;
import com.ecommerce.product_service.repository.ReviewRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class ReviewServiceTest {

    @Mock
    private ReviewRepository reviewRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private ReviewService reviewService;

    private Product product;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        product = Product.builder()
                .id(1L)
                .name("Test Product")
                .rating(0.0)
                .build();
    }

    @Test
    void addReview_ShouldAddReviewAndUpdateProductRating() {
        // Given
        ReviewRequest request = ReviewRequest.builder()
                .productId(1L)
                .userId(100L)
                .rating(5)
                .comment("Excellent")
                .build();

        Review review = Review.builder()
                .id(10L)
                .product(product)
                .userId(100L)
                .rating(5)
                .comment("Excellent")
                .createdAt(LocalDateTime.now())
                .build();

        when(productRepository.findById(1L)).thenReturn(Optional.of(product));
        when(reviewRepository.save(any(Review.class))).thenReturn(review);
        when(reviewRepository.findByProductId(1L)).thenReturn(List.of(review));

        // When
        ReviewResponse response = reviewService.addReview(request);

        // Then
        assertNotNull(response);
//        assertEquals(10L, response.getId());
        assertEquals(1L, response.getProductId());
        assertEquals(5, response.getRating());
        assertEquals("Excellent", response.getComment());

        verify(productRepository, times(1)).save(any(Product.class));
        verify(reviewRepository, times(1)).save(any(Review.class));
    }

    @Test
    void getReviewsByProduct_ShouldReturnListOfReviews() {
        // Given
        Review review1 = Review.builder()
                .id(1L)
                .product(product)
                .rating(4)
                .comment("Good")
                .build();

        Review review2 = Review.builder()
                .id(2L)
                .product(product)
                .rating(5)
                .comment("Excellent")
                .build();

        when(reviewRepository.findByProductId(1L)).thenReturn(List.of(review1, review2));

        // When
        List<ReviewResponse> reviews = reviewService.getReviewsByProduct(1L);

        // Then
        assertEquals(2, reviews.size());
        assertEquals(4, reviews.get(0).getRating());
        assertEquals("Good", reviews.get(0).getComment());
        assertEquals(5, reviews.get(1).getRating());
        assertEquals("Excellent", reviews.get(1).getComment());
    }

    @Test
    void addReview_ShouldThrowException_WhenProductNotFound() {
        // Given
        ReviewRequest request = ReviewRequest.builder()
                .productId(999L)
                .userId(100L)
                .rating(3)
                .comment("Average")
                .build();

        when(productRepository.findById(999L)).thenReturn(Optional.empty());

        // When / Then
        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> reviewService.addReview(request));

        assertEquals("Product not found", ex.getMessage());
        verify(reviewRepository, never()).save(any(Review.class));
    }
}
