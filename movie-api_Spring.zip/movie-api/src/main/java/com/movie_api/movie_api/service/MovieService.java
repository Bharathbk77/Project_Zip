package com.movie_api.movie_api.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.movie_api.movie_api.model.Movie;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;
@Service
public class MovieService {

    private List<Movie> movies;

    @PostConstruct
    public void init(){
        try {
            ObjectMapper obj=new ObjectMapper();
            InputStream in = getClass().getClassLoader().getResourceAsStream("movies.json");
            movies=obj.readValue(in, new TypeReference<List<Movie>>() {});
            System.out.println("Data Loaded..........");
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    public List<Movie> getAllMovies(){
        return movies;
    }
    public Movie getMovieById(int id){
        return movies.stream().
                filter(m->m.getId()==id)
                .findFirst()
                .orElseThrow(()->new RuntimeException("No ID Found"));
    }
    public Movie deleteMovie(int id){
       Movie movieToDelete=getMovieById(id);
       movies.remove(movieToDelete);
       return movieToDelete;
    }
    public Movie updateMovie(int id,Movie movie){
        Movie movieToUpdate=getMovieById(id);
        movieToUpdate.setTitle(movie.getTitle());
        movieToUpdate.setDirector(movie.getDirector());
        movieToUpdate.setActor(movie.getActor());
        movieToUpdate.setActress(movie.getActress());
        movieToUpdate.setGenre(movie.getGenre());
        movieToUpdate.setBudget(movie.getBudget());
        movieToUpdate.setRating(movie.getRating());
        return movieToUpdate;
    }

}
