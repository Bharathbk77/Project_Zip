package com.example.BookingApp.service;

import com.example.BookingApp.dto.OrderDTO;
import com.example.BookingApp.dto.OrderRequestDto;
import com.example.BookingApp.dto.OrderResponseDto;
import com.example.BookingApp.dto.ProductDTO;
import com.example.BookingApp.entity.Order;
import com.example.BookingApp.entity.Product;
import com.example.BookingApp.repository.OrderRepository;
import com.example.BookingApp.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final TalonOneService talonOneService;

    @Autowired
    public OrderService(OrderRepository orderRepository, ProductRepository productRepository, TalonOneService talonOneService) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.talonOneService = talonOneService;
    }

    public void placeOrder(OrderDTO orderDTO) {
        List<Product> products = productRepository.findAllById(
                orderDTO.getProducts().stream().map(ProductDTO::getId).collect(Collectors.toList())
        );
        double totalPrice = products.stream().mapToDouble(Product::getPrice).sum();
        double discountPrice = talonOneService.evaluateDiscount(orderDTO);
        Order order = new Order();
        order.setOrderDate(orderDTO.getOrderDate());
        order.setProducts(products);
        order.setTotalPrice(totalPrice);
        order.setDiscountPrice(discountPrice);
        orderRepository.save(order);
    }

    public OrderResponseDto createOrder(@Valid OrderRequestDto orderRequestDto) {

    }
    public Order getOrderById(Long id){

    }
}
