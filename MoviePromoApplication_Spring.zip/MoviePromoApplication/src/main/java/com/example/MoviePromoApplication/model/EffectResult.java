package com.example.MoviePromoApplication.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class EffectResult {
    private String effectType;
    private double value;
    private String description;
}