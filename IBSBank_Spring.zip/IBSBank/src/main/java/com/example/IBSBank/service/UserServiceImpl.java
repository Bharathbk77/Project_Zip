package com.example.IBSBank.service;

import com.example.IBSBank.dto.RegisterRequest;
import com.example.IBSBank.dto.RegisterResponse;
import com.example.IBSBank.entity.User;
import com.example.IBSBank.exception.ResourceAlreadyExistsException;
import com.example.IBSBank.repository.UserRepository;
import com.example.IBSBank.util.AccountNumberGenerator;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService{

    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;
    private final MailService mailService;

    @Override
    public RegisterResponse register(RegisterRequest request) {
        userRepository.findByEmail(request.getEmail()).ifPresent((user -> {
            throw new ResourceAlreadyExistsException("Email already exists: " + request.getEmail());
        }));

        User user= User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .accountNumber(AccountNumberGenerator.generate())
                .balance(0.0)
                .role("USER")
                .status("ACTIVE")
                .kycVerified(false)
                .phoneNumber(request.getPhoneNumber())
                .address(request.getAddress())
                .gender(request.getGender())
                .dob(request.getDob())
                .build();
        userRepository.save(user);
// ✅ Send email after successful registration
        mailService.sendRegistrationEmail(user.getEmail(), user.getFullName(), user.getAccountNumber());
        return RegisterResponse.builder()
                .message("User Registered Successfully")
                .email(user.getEmail())
                .accountNumber(user.getAccountNumber())
                .userId(user.getId())
                .build();
    }

}
