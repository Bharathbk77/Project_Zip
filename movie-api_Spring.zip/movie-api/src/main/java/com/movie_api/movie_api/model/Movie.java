package com.movie_api.movie_api.model;


public class Movie {
    private int id;
    private String title;
    private String director;
    private String actor;
    private String actress;
    private String genre;
    private long budget;
    private double rating;

    public Movie() {}

    public Movie(int id, String title, String director, String actor, String actress, String genre, long budget, double rating) {
        this.id = id;
        this.title = title;
        this.director = director;
        this.actor = actor;
        this.actress = actress;
        this.genre = genre;
        this.budget = budget;
        this.rating = rating;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getActress() {
        return actress;
    }

    public void setActress(String actress) {
        this.actress = actress;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public long getBudget() {
        return budget;
    }

    public void setBudget(long budget) {
        this.budget = budget;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
