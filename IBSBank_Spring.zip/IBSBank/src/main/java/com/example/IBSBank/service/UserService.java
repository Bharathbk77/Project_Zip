package com.example.IBSBank.service;

import com.example.IBSBank.dto.RegisterRequest;
import com.example.IBSBank.dto.RegisterResponse;

public interface UserService {
    RegisterResponse register(RegisterRequest request);
}
