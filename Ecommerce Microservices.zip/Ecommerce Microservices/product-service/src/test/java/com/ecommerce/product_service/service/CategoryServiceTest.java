package com.ecommerce.product_service.service;

import com.ecommerce.product_service.service.CategoryService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


import com.ecommerce.product_service.dto.CategoryRequest;
import com.ecommerce.product_service.dto.CategoryResponse;
import com.ecommerce.product_service.entity.Category;
import com.ecommerce.product_service.repository.CategoryRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CategoryServiceTest {

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private CategoryService categoryService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this); // initializes mocks
    }

    @Test
    void saveCategory_ShouldReturnCategoryResponse() {
        // Given
        CategoryRequest request = new CategoryRequest("Electronics");
        Category savedCategory = Category.builder()
                .id(1L)
                .name("Electronics")
                .build();

        when(categoryRepository.save(any(Category.class))).thenReturn(savedCategory);

        // When
        CategoryResponse response = categoryService.saveCategory(request);

        // Then
        assertNotNull(response);
//		assertEquals(1L, response.getId());
        assertEquals("Electronics", response.getName());

        verify(categoryRepository, times(1)).save(any(Category.class));
    }

    @Test
    void getAllCategories_ShouldReturnListOfCategoryResponses() {
        // Given
        List<Category> categories = Arrays.asList(
                Category.builder().id(1L).name("Electronics").build(),
                Category.builder().id(2L).name("Clothing").build()
        );
        when(categoryRepository.findAll()).thenReturn(categories);

        // When
        List<CategoryResponse> responses = categoryService.getAllCategories();

        // Then
        assertEquals(2, responses.size());
        assertEquals("Electronics", responses.get(0).getName());
        assertEquals("Clothing", responses.get(1).getName());

        verify(categoryRepository, times(1)).findAll();
    }
}

