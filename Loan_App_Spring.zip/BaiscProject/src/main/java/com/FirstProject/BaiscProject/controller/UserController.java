package com.FirstProject.BaiscProject.controller;

import com.FirstProject.BaiscProject.entity.User;
import com.FirstProject.BaiscProject.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import  java.util.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @PostMapping
    public User createUser(@RequestBody User user) {
        return userRepository.save(user);
    }

    @GetMapping("/{id}")
    public User getUserById(@PathVariable Long id) {
        return userRepository.findById(id).orElse(null);
    }
    @GetMapping("/")
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
}