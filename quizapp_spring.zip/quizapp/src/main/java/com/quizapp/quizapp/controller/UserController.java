//    package com.quizapp.quizapp.controller;
//
//    import com.quizapp.quizapp.entity.User;
//    import com.quizapp.quizapp.service.UserService;
//    import org.springframework.beans.factory.annotation.Autowired;
//    import org.springframework.http.HttpStatus;
//    import org.springframework.http.ResponseEntity;
//    import org.springframework.web.bind.annotation.*;
//
//    import java.util.HashMap;
//    import java.util.List;
//    import java.util.Map;
//
//    @RestController
//    @RequestMapping("api/users")
//    public class UserController {
//        @Autowired
//        private UserService userService;
//
//        @PostMapping("/register")
//        public ResponseEntity<?> registerUser(@RequestBody User user){
//            try {
//                // Validate required fields
//                if (user.getName() == null || user.getName().isEmpty() ||
//                        user.getEmail() == null || user.getEmail().isEmpty() ||
//                        user.getPassword() == null || user.getPassword().isEmpty()) {
//                    Map<String, String> errorResponse = new HashMap<>();
//                    errorResponse.put("error", "Name, email, and password are required");
//                    return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
//                }
//
//                User savedUser = userService.registerUser(user);
//                return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
//            } catch (Exception e) {
//                Map<String, String> errorResponse = new HashMap<>();
//                errorResponse.put("error", "Registration failed: " + e.getMessage());
//                return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//        }
//
//        @GetMapping("/{username}")
//        public ResponseEntity<?> getUser(@PathVariable String username){
//            try {
//                User user = userService.findByUser(username);
//                if (user == null) {
//                    Map<String, String> errorResponse = new HashMap<>();
//                    errorResponse.put("error", "User not found");
//                    return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
//                }
//                return new ResponseEntity<>(user, HttpStatus.OK);
//            } catch (Exception e) {
//                Map<String, String> errorResponse = new HashMap<>();
//                errorResponse.put("error", "Error fetching user: " + e.getMessage());
//                return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//        }
//        @GetMapping("/all")
//        public ResponseEntity<?> getAllUsers() {
//            try {
//                List<User> users = userService.getAllUsers();
//                return new ResponseEntity<>(users, HttpStatus.OK);
//            } catch (Exception e) {
//                Map<String, String> errorResponse = new HashMap<>();
//                errorResponse.put("error", "Error fetching all users: " + e.getMessage());
//                return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
//            }
//        }
//
//        @GetMapping("/hello")
//        public String hello() {
//            return "Backend running!";
//        }
//    }

package com.quizapp.quizapp.controller;

import java.util.List;
import java.util.Optional;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.quizapp.quizapp.entity.User;
import com.quizapp.quizapp.service.UserService;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

    @GetMapping("/all")
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    @GetMapping("/{name}")
    public ResponseEntity<?> getUser(@PathVariable String name) {
        Optional<User> user = userService.getUserByName(name);
        if (user.isPresent()) {
            return ResponseEntity.ok(user.get());
        } else {
            Map<String, String> error = new HashMap<>();
            error.put("error", "User not found");
            return ResponseEntity.status(404).body(error);
        }
    }

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
        try {
            User savedUser = userService.registerUser(user);
            return ResponseEntity.ok(savedUser);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("error", "Registration failed: " + e.getMessage());
            return ResponseEntity.status(500).body(error);
        }
    }
}
