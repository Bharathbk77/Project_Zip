package com.example.IRCTC.irctc.service;

import com.example.IRCTC.irctc.entity.Passenger;
import com.example.IRCTC.irctc.repository.PassengerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PassengerService {

    @Autowired
    PassengerRepository passengerRepository;

    public Passenger savePassenger(Passenger passenger){
        return passengerRepository.save(passenger);
    }
    public List<Passenger> getallPassengers(){
        return passengerRepository.findAll();
    }
    public Passenger getById(Long id){
        return passengerRepository.findById(id).orElse(null);
    }
    public Passenger getByName(String name){
        return passengerRepository.findByName(name).orElse(null);
    }
    public void deletePassengerById(Long id) {
         passengerRepository.deleteById(id);
    }
    public Passenger updatePassenger(Long id,Passenger updatedpassenger){
        Passenger current_passenger=passengerRepository.findById(id).orElse(null);
        if(current_passenger!=null){
            current_passenger.setName(updatedpassenger.getName());;
            current_passenger.setAge(updatedpassenger.getAge());
            current_passenger.setGender(updatedpassenger.getGender());
            current_passenger.setPhoneNumber(updatedpassenger.getPhoneNumber());

            return passengerRepository.save(current_passenger);
        }
        return null;
    }
}
