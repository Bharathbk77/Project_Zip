package com.taskmanager.taskmanager.service;

import com.taskmanager.taskmanager.entity.User;
import com.taskmanager.taskmanager.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User saveUser(User user){
        return userRepository.save(user);
    }
    public List<User> getAllUser(){
        return userRepository.findAll();
    }
    public Optional<User> getUserById(Long id){
        return userRepository.findById(id);
    }
    public void  deleteUserById(Long id){
        userRepository.deleteById(id);
    }
//    public String  deleteUserById(Long id){
//        userRepository.deleteById(id);//another way to delete with String type
//        return "User deleted Sucessfully";
//    }
    public User updateUser(Long id,User userDetails){
        Optional<User> optionalUser=userRepository.findById(id);

        if(optionalUser.isPresent()){
            User u1=optionalUser.get();
            u1.setName(userDetails.getName());
            u1.setEmail(userDetails.getEmail());

            return userRepository.save(u1);
        }
        else{
            throw new IllegalArgumentException("User Not Found!");
        }
    }


}
