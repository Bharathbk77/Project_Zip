package com.chat_app_backend.chat_app_backend.controller;

import com.chat_app_backend.chat_app_backend.model.ChatMessage;
import com.chat_app_backend.chat_app_backend.model.MessageType;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

@Controller
public class ChatController {

    // Handles messages sent to /app/chat.sendMessage
    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessage sendMessage(ChatMessage chatMessage) {
        // You can add logic here (e.g., save to DB)
        return chatMessage;  // Broadcast the message to all subscribers of /topic/public
    }

    // Handles new user join messages sent to /app/chat.addUser
    @MessageMapping("/chat.addUser")
    @SendTo("/topic/public")
    public ChatMessage addUser(ChatMessage chatMessage) {
        chatMessage.setType(MessageType.JOIN);
        return chatMessage;  // Notify all subscribers that a new user has joined
    }
}
