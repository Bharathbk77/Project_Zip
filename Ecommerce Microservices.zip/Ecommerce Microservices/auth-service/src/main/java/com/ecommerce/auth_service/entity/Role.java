package com.ecommerce.auth_service.entity;

public enum Role {
    ADMIN, CUSTOMER
}
