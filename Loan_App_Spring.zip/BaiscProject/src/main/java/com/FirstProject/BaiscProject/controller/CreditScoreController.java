package com.FirstProject.BaiscProject.controller;

import com.FirstProject.BaiscProject.model.LoanEligibility;
import com.FirstProject.BaiscProject.service.CreditScoreService;
import  com.FirstProject.BaiscProject.repository.CreditScoreRepository;
import com.FirstProject.BaiscProject.entity.CreditScore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/score")
public class CreditScoreController {

    @Autowired
    private CreditScoreService scoreService;

    @Autowired
    private CreditScoreRepository scoreRepo;



    @GetMapping("/eligibility/{userId}")
    public LoanEligibility getLoanEligibility(@PathVariable Long userId) {
        return scoreService.checkEligibility(userId);
    }
    @PostMapping
    public CreditScore createScore(@RequestBody CreditScore score) {
        return scoreRepo.save(score);
    }
    @GetMapping
    public List<CreditScore> getAllScores() {
        return scoreRepo.findAll();
    }

}

