package com.example.BookingApp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderResponseDto {

    private Long orderId;
    private Long userId;
    private List<String> productNames;
    private BigDecimal totalAmount;
    private BigDecimal discountedAmount;
    private String status;
}
