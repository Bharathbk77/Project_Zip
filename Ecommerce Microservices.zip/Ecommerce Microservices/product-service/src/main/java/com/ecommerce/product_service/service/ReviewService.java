package com.ecommerce.product_service.service;

import com.ecommerce.product_service.dto.ReviewRequest;
import com.ecommerce.product_service.dto.ReviewResponse;
import com.ecommerce.product_service.entity.Product;
import com.ecommerce.product_service.entity.Review;
import com.ecommerce.product_service.repository.ProductRepository;
import com.ecommerce.product_service.repository.ReviewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ReviewService {

    private final ReviewRepository reviewRepository;
    private final ProductRepository productRepository;

    // Add review for a product
    public ReviewResponse addReview(ReviewRequest request) {
        Product product = productRepository.findById(request.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Review review = Review.builder()
                .product(product)
                .userId(request.getUserId())
                .rating(request.getRating())
                .comment(request.getComment())
                .createdAt(LocalDateTime.now())
                .build();

        reviewRepository.save(review);

        // Update product average rating
        double avgRating = reviewRepository.findByProductId(request.getProductId())
                .stream()
                .mapToInt(Review::getRating)
                .average()
                .orElse(0.0);
        product.setRating(avgRating);
        productRepository.save(product);

        return ReviewResponse.builder()
                .id(review.getId())
                .productId(product.getId())
                .rating(review.getRating())
                .comment(review.getComment())
                .build();
    }

    // Get all reviews for a product
    public List<ReviewResponse> getReviewsByProduct(Long productId) {
        return reviewRepository.findByProductId(productId).stream()
                .map(r -> ReviewResponse.builder()
                        .id(r.getId())
                        .productId(r.getProduct().getId())
                        .rating(r.getRating())
                        .comment(r.getComment())
                        .build())
                .toList();
    }
}
