package com.example.IRCTC.irctc.service;

import com.example.IRCTC.irctc.entity.Passenger;
import com.example.IRCTC.irctc.repository.PassengerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PassengerServiceTest {

    @Mock
    private PassengerRepository passengerRepository;

    @InjectMocks
    private PassengerService passengerService;

    private Passenger passenger;

    @BeforeEach
    public void setup() {
        passenger = new Passenger();
        passenger.setId(1);
        passenger.setName("Bharath");
        passenger.setAge(23);
        passenger.setGender("Male");
        passenger.setPhoneNumber(989898989);
    }

    @Test
    public void testSavePassenger() {
        when(passengerRepository.save(passenger)).thenReturn(passenger);

        Passenger result = passengerService.savePassenger(passenger);

        assertNotNull(result);
        assertEquals("Bharath", result.getName());
    }
    @Test
    public void testgetallPassengers(){
        List<Passenger> list=new ArrayList<>();
        Passenger p1=new Passenger();
        p1.setId(1);
        p1.setName("Bharath");
        p1.setAge(23);
        p1.setGender("Male");
        p1.setPhoneNumber(989898989);

        Passenger p2 = new Passenger();
        p2.setId(2);
        p2.setName("Kumar");
        p2.setAge(30);
        p2.setGender("Male");
        p2.setPhoneNumber(987654321);

        list.add(p1);
        list.add(p2);

        when(passengerRepository.findAll()).thenReturn(list);

        List<Passenger>  result=passengerService.getallPassengers();

        assertNotNull(result);

        assertEquals(2,result.size());
        assertEquals("Bharath", result.get(0).getName());
        assertEquals("Kumar", result.get(1).getName());
    }
    @Test
    public void testGetPassengerById() {
        Passenger p1 = new Passenger();
        p1.setId(1L);
        p1.setName("Bharath");
        p1.setAge(23);
        p1.setGender("Male");
        p1.setPhoneNumber(989898989);

        when(passengerRepository.findById(1L)).thenReturn(Optional.of(p1));

        Passenger result = passengerService.getById(1L);

        assertNotNull(result);
        assertEquals("Bharath", result.getName());
    }

}
