package com.example.BookingApp.service;

import com.example.BookingApp.dto.OrderRequestDto;
import com.example.BookingApp.dto.OrderResponseDto;
import com.example.BookingApp.dto.ProductDTO;
import com.example.BookingApp.entity.Order;
import com.example.BookingApp.entity.Product;
import com.example.BookingApp.repository.OrderRepository;
import com.example.BookingApp.repository.ProductRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    private final OrderRepository orderRepository;
    private final ProductRepository productRepository;
    private final TalonOneService talonOneService;

    @Autowired
    public OrderService(OrderRepository orderRepository, ProductRepository productRepository, TalonOneService talonOneService) {
        this.orderRepository = orderRepository;
        this.productRepository = productRepository;
        this.talonOneService = talonOneService;
    }

    // ✅ Create a new order
    public OrderResponseDto createOrder(@Valid OrderRequestDto orderRequestDto) {
        List<Product> products = productRepository.findAllById(
                orderRequestDto.getProducts().stream()
                        .map(ProductDTO::getId)
                        .collect(Collectors.toList())
        );

        if (products.isEmpty()) {
            throw new IllegalArgumentException("No valid products found for the order");
        }

        double totalPrice = products.stream().mapToDouble(Product::getPrice).sum();
        double discountPrice = talonOneService.evaluateDiscount(orderRequestDto);

        Order order = new Order();
        order.setOrderDate(orderRequestDto.getOrderDate());
        order.setProducts(products);
        order.setTotalPrice(totalPrice);
        order.setDiscountPrice(discountPrice);

        Order savedOrder = orderRepository.save(order);

        return mapToResponseDto(savedOrder);
    }

    // ✅ Fetch order by ID and return DTO
    public OrderResponseDto getOrderById(Long id) {
        Optional<Order> optionalOrder = orderRepository.findById(id);
        return optionalOrder.map(this::mapToResponseDto).orElse(null);
    }

    // ✅ Convert Order → OrderResponseDto
    private OrderResponseDto mapToResponseDto(Order order) {
        return new OrderResponseDto(
                order.getId(),
                order.getOrderDate(),
                order.getTotalPrice(),
                order.getDiscountPrice(),
                order.getProducts().stream()
                        .map(ProductDTO::fromEntity)
                        .collect(Collectors.toList())
        );
    }
}
