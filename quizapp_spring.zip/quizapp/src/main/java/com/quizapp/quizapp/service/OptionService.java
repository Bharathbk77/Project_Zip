package com.quizapp.quizapp.service;

import com.quizapp.quizapp.entity.Option;
import com.quizapp.quizapp.entity.Question;
import com.quizapp.quizapp.repository.OptionRepository;
import com.quizapp.quizapp.repository.QuestionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OptionService {
    @Autowired
    private OptionRepository optionRepository;

    @Autowired
    private QuestionRepository questionRepository;
    public List<Option> addOptionsToQuestion(List<Option> options, Long questionId) {
        Question question = questionRepository.findById(questionId)
                .orElseThrow(() -> new RuntimeException("Question not found with id: " + questionId));

        for (Option option : options) {
            option.setQuestion(question);
        }

        return optionRepository.saveAll(options);
    }

    public List<Option> getOptionsByQuestion(Long questionId){
        return optionRepository.findByQuestionId(questionId);
    }

}
