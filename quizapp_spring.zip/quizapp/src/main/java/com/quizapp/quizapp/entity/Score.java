package com.quizapp.quizapp.entity;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "scores")
public class Score {

    @Id
    private Long id;
    private int score;
    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user;
    @ManyToOne
    @JoinColumn(name = "quiz_id")
    private Quiz quiz;
    @OneToMany(mappedBy = "score", cascade = CascadeType.ALL)
    private List<UserAnswer> userAnswers;

    // Constructor with parameters
    public Score(int score, User user, Quiz quiz, List<UserAnswer> userAnswers) {
        this.score = score;
        this.user = user;
        this.quiz = quiz;
        this.userAnswers = userAnswers;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Quiz getQuiz() {
        return quiz;
    }

    public void setQuiz(Quiz quiz) {
        this.quiz = quiz;
    }

    public List<UserAnswer> getUserAnswers() {
        return userAnswers;
    }

    public void setUserAnswers(List<UserAnswer> userAnswers) {
        this.userAnswers = userAnswers;
    }
}
