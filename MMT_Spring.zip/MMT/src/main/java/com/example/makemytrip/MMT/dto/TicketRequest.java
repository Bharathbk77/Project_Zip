package com.example.makemytrip.MMT.dto;

import lombok.Data;

@Data
public class TicketRequest {
    private Long passengerId;
    private Long trainId;
    private String status;
}
